from trio._repl import main

main(locals())
